package progweb3.poa.ifrs.edu.agendabd;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class ListProvasActivity extends AppCompatActivity {
    private ListView listProvas;
    private Button botaoVoltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_provas);
        listProvas = (ListView)this.findViewById(R.id.listViewTarefas);
        this.getAll();
    }
    protected  void getAll(){
        ProvaRepository provaRepository = new ProvaRepository(this);
        List<Prova> provas = provaRepository.getAll();
        listProvas.setAdapter(new ConsultaAdapter(this, provas));
    }
}
