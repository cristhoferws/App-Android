package progweb3.poa.ifrs.edu.agendabd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 0067156 on 24/05/2017.
 */




public class ProvaRepository {
    private BDUtil bdUtil;

    public ProvaRepository(Context context){
        bdUtil =  new BDUtil(context);
    }

    public String insert(String nome, String descricao, String data){
        ContentValues valores = new ContentValues();
        valores.put("NOME", nome);
        valores.put("DESCRICAO", descricao);
        valores.put("DATA", data);
        long resultado = bdUtil.getConexao().insert("PROVA", null, valores);
        if (resultado ==-1)
            return "Erro ao inserir registro";
        return "Registro Inserido com sucesso";
    }
    public Integer delete(int codigo){
        return bdUtil.getConexao().delete("PROVA","_id = ?", new String[]{Integer.toString(codigo)});
    }

    public List<Prova> getAll(){
        List<Prova> provas = new ArrayList<>();
        // monta a consulta
        StringBuilder stringBuilderQuery = new StringBuilder();
        stringBuilderQuery.append("SELECT _ID, NOME, DESCRICAO, DATA ");
        stringBuilderQuery.append("FROM  PROVA ");
        stringBuilderQuery.append("ORDER BY NOME");
        //consulta os registros que estão no BD
        Cursor cursor = bdUtil.getConexao().rawQuery(stringBuilderQuery.toString(), null);
        //aponta cursos para o primeiro registro
        cursor.moveToFirst();
        Prova prova = null;
        //Percorre os registros até atingir o fim da lista de registros
        while (!cursor.isAfterLast()){
            // Cria objetos do tipo tarefa
            prova =  new Prova();
            //adiciona os dados no objeto
            prova.set_id(cursor.getInt(cursor.getColumnIndex("_ID")));
            prova.setNome(cursor.getString(cursor.getColumnIndex("NOME")));
            prova.setDescricao(cursor.getString(cursor.getColumnIndex("DESCRICAO")));
            prova.setData(cursor.getString(cursor.getColumnIndex("DATA")));
            //adiciona o objeto na lista
            provas.add(prova);
            //aponta para o próximo registro
            cursor.moveToNext();
        }
        //retorna a lista de objetos
        return provas;
    }
    public Prova getTarefa(int codigo){
        Cursor cursor =  bdUtil.getConexao().rawQuery("SELECT * FROM PROVA WHERE _ID = "+ codigo,null);
        cursor.moveToFirst();
       Prova t = new Prova();
        t.set_id(cursor.getInt(cursor.getColumnIndex("_ID")));
        t.setNome(cursor.getString(cursor.getColumnIndex("NOME")));
        t.setDescricao(cursor.getString(cursor.getColumnIndex("DESCRICAO")));
        t.setData(cursor.getString(cursor.getColumnIndex("DATA")));
        return t;
    }

    public void update(Prova prova){
        ContentValues contentValues =  new ContentValues();
        contentValues.put("NOME",       prova.getNome());
        contentValues.put("DESCRICAO",   prova.getDescricao());
        contentValues.put("DATA",       prova.getData());
        //atualiza o objeto usando a chave
        bdUtil.getConexao().update("PROVA", contentValues, "_id = ?", new String[]{Integer.toString(prova.get_id())});
    }
}
