package com.example.a0081159.myapplication;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Vincula a toolbar ao layout
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        //quando carregar a atividade vai carregar essa toolbar
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        //vincula o menu a toolbar com os itens definidos no
        //layout menubarra
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    //codigo para manipular os itens que estao na barra
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        //se o usuario seleciona pesquisa
        if (id == R.id.pesquisa){
            return true;
        } //se o usuario seleciona info
        else if( id == R.id.informacao){
            //abre janela de dialogo
            mostraDialogo();
        }
    }

    private void mostraDialogo(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Titulo");
        builder.setMessage("Digite aqui sua mensagem!");
        //define um botao como positivo
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Toast.makeText(MainActivity.this, "Voce clicou no botao OK", Toast.LENGTH_SHORT).show();
            }
        });
        //define um botao como negativo
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface arg0, int arg1){
                Toast.makeText(MainActivity.this, "Voce clicou no botao cancelar", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog alerta = builder.create();
        alerta.show();//mostra a janela
    }
}
