package com.example.a0081159.myapplication;

/**
 * Created by 0081159 on 07/06/2017.
 */

public interface ClickRecycle {
    void onCustomClick(Object object);
}
