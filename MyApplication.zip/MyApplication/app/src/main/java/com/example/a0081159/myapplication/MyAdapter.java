package com.example.a0081159.myapplication;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.widget.Adapter;

import java.util.List;

/**
 * Created by 0081159 on 07/06/2017.
 */

public class MyAdapter extends
        RecyclerView.Adapter<MyAdapter.MyViewHolder>  {
    public static ClickRecycle clickRecycle;
    Context contexto;
    private List<Pessoa> listPessoas;
    public MyAdapter(Context ctx, List<Pessoa> list, ClickRecycle clickRecycle){
        this.contexto = ctx;
        this.listPessoas = list;
        this.clickRecycle = clickRecycle;
    }

}
